// Importa el hook useState de React para manejar el estado local
import { useState } from "react"

// Componente funcional Rate
function Rate() {
  // Estado para guardar la calificación seleccionada (de 0 a 5)
  const [raiting, setRaitin] = useState(0)
  // Crea un arreglo de 5 elementos para representar las estrellas
  const starts = Array.from({length: 5}, (_,i)=>(i+1))

  // Retorna el JSX que representa el sistema de calificación
  return (
    // Fragmento vacío para no agregar nodos extra al DOM
    <>
      <div>
        {/* Contenedor de las estrellas */}
        <div className="stars">
          {/* Recorre el arreglo de estrellas y genera un span para cada una */}
          {starts.map((star, i) => (
            // Si la estrella es mayor que la calificación, se muestra como "star" (gris), si no como "active" (amarilla)
            <span key={i} className={star > raiting ? "star" : "active"}>
              {/* Al hacer clic en la estrella, se actualiza la calificación */}
              <a onClick={() => (
                setRaitin((prev) => {
                  // Muestra en consola el valor anterior de la calificación
                  console.log(prev);
                  // Retorna el nuevo valor de la calificación
                  return star;
                })
              )}>
                {'\u2605'} {/* Código Unicode para la estrella */}
              </a>
            </span>
          ))}
        </div>
      </div>
    </>
  )
}

// Exporta el componente Rate para que pueda ser usado en otros archivos
export default Rate